create function postgraphile.customers_full_name(customer postgraphile.customers) returns text as $$
	select customer.firstname || ' ' || customer.lastname
$$ language sql stable;