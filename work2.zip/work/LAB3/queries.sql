

# OLEG PETCOV
# C14399846
# DT228/4 COMPUTER SCIENCE
# ENTERPRISE APPLICATION DEVELOPMENT
# LAB 3


# Launch the postgraphile thing from CMD:
# 	postgraphile is the name of my schema, and it is some sort of some package too
# 	my query:	postgraphile --watch -c "postgres://postgres:postgres@localhost:5432/dellstore2" -s postgraphile
# 	your query:	postgraphile --watch -c "postgres://USERNAME:PASSWORD@localhost:5432/DBNAME" -s postgraphile


# Browser launch
# http://localhost:5000/graphiql






# Part1 
#	add foreign keys, etc


//orderlines
ALTER TABLE ONLY postgraphile.orderlines
    ADD CONSTRAINT fk_prod_id FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;
	
//cust_hist	
ALTER TABLE ONLY postgraphile.cust_hist
    ADD CONSTRAINT fk_cust_hist_prod_id FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;
	
ALTER TABLE ONLY postgraphile.cust_hist
    ADD CONSTRAINT fk_cust_hist_orderid FOREIGN KEY (orderid) REFERENCES postgraphile.orders(orderid) ON DELETE CASCADE;


//categories
ALTER TABLE ONLY postgraphile.products
    ADD CONSTRAINT fk_products_category FOREIGN KEY (category) REFERENCES postgraphile.categories(category) ON DELETE CASCADE;
	
	
//inventory
ALTER TABLE ONLY postgraphile.inventory
    ADD CONSTRAINT fk_inventory_products FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;

//reorder
ALTER TABLE ONLY postgraphile.reorder
    ADD CONSTRAINT fk_reorder_products FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;
	







# Part2
# 	user-defined query and other queries

{
  query getAll{
    allCustomers {
      nodes {
        firstname
        customerid
      }
    }
  }
}



# user-defined function
# user-defined.sql
# help from here
# 	https://www.youtube.com/watch?v=b3pwlCDy6vY

query fullName{
  allCustomers(first: 5){
    nodes {
      fullName
    }
  }
}



# pass a variable into the fucntion
query part2($cid: Int!){

  customerByCustomerid(customerid: $cid) {
    	customerid
		firstname
    	lastname
  }
}


## COMMAND: {"cid": 2}










# Part3
#	 do some join thing here
# 	 E.G 
#		get customer, order, and products data, using customerid = whatever


query part3($cid: Int!){

  customerByCustomerid(customerid: $cid) {
      fullName
    	address1
    	address2
    	ordersByCustomerid{
        
        nodes{
		  orderid
          orderdate
          totalamount
          
          orderlinesByOrderid{
            nodes{
              prodId
              quantity
              productByProdId{
                  title
				  price
              }
            }
          }
        }
      }
	}  	
}


## COMMAND: {"cid": 2}








# Part4 New Order
mutation newOrder($clientMutID: String = "", $ordDate: Date!, $custID: Int = 0, $ordNet: BigFloat!, $ordTax: BigFloat!, $ordTotal: BigFloat!){
  
  createOrder(input: {
    clientMutationId:$clientMutID
    
    order:{
      orderdate: $ordDate
      customerid: $custID
      netamount: $ordNet
      tax: $ordTax
      totalamount: $ordTotal
    }  
  }) {
    order {
    	orderid
      orderdate
      customerid
      netamount
      tax
      totalamount
  	}
  }  
}

## COMMAND: {"clientMutID": "testMutID","ordDate": "01/01/2018", "custID": 1, "ordNet": 999.99, "ordTax": 12, "ordTotal": 999.99}




###################
#       NB        #
###################


# Find the newly created order, use the 'orderid' that was generated to manually insert into the commands below

query getOrdID($oid: Int!){

  orderByOrderid(orderid: $oid) {
    orderid
    orderdate
    customerid
    netamount
    tax
    totalamount
  }
}


###################
#      END NB     #
###################







# Part4 New OrderLine
mutation newOrderLine($clientMutID: String = "", $ordDate: Date!, $ordID: Int!, $ordLineID: Int!, $ordQuantity: Int!, $ordProduct:Int!){
  
  createOrderline(input: {
      clientMutationId: $clientMutID

      orderline:{
        orderid: $ordID
        orderlineid: $ordLineID
        prodId: $ordProduct
        quantity: $ordQuantity
        orderdate: $ordDate
      }
    }){
      orderline {
        orderlineid
        orderid
        prodId
        quantity
        orderdate
      }
  } 
}


## COMMAND: {"clientMutID": "testMutID","ordDate": "01/01/2018", "ordID": 12001, "ordLineID": 1, "ordQuantity": 3, "ordProduct": 3}








# Part4 New CustHist
mutation newCustHist($clientMutID: String = "", $custID: Int = 0, $ordID: Int!, $ordProduct:Int!){
  

  createCustHist(input:{
      clientMutationId: $clientMutID

      custHist:{
        customerid: $custID
        orderid: $ordID
        prodId: $ordProduct
      }
    }){
      custHist{
        customerid
        orderid
        prodId
      }
    }
  
}



## COMMAND: {"clientMutID": "testMutID", "custID": 1, "ordID": 12001, "ordProduct": 3}















# Part5, do some thing using Express, or w/e


query getCust($cid: Int!){
  
  customer(custID:$cid){
  customerid
  firstname
  lastname
}}

## COMMAND: {"cid": 2}


# final.js file





















