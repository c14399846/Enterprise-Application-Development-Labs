
# Part2, user-defined query


query fullName{
  allCustomers(first: 5){
    nodes {
      fullName
    }
  }
}



query part2($cid: Int!){

  customerByCustomerid(customerid: $cid) {
    	customerid
      firstname
    	lastname
  }
}








# Part3, do some join thing here
query part3($cid: Int!){

  customerByCustomerid(customerid: $cid) {
      fullName
    	address1
    	address2
    	ordersByCustomerid{
        
        nodes{
        	orderid
          orderdate
          totalamount
          
          orderlinesByOrderid{
            nodes{
              prodId
              quantity
              productByProdId{
                  title
               		price
              }
            }
          }
        }
      }
	}  	
}





# Part4 New Order
mutation newOrder($clientMutID: String = "", $ordDate: Date!, $custID: Int = 0, $ordNet: BigFloat!, $ordTax: BigFloat!, $ordTotal: BigFloat!){
  
  
  
  createOrder(input: {
    clientMutationId:$clientMutID
    
    order:{
      orderdate: $ordDate
      customerid: $custID
      netamount: $ordNet
      tax: $ordTax
      totalamount: $ordTotal
    }  
  }) {
    order {
    	orderid
      orderdate
      customerid
      netamount
      tax
      totalamount
  	}
  }
  
}



# Part4 New OrderLine
mutation newOrderLine($clientMutID: String = "", $ordDate: Date!, $ordID: Int!, $ordLineID: Int!, $ordQuantity: Int!, $ordProduct:Int!){
  
  createOrderline(input: {
      clientMutationId: $clientMutID

      orderline:{
        orderid: $ordID
        orderlineid: $ordLineID
        prodId: $ordProduct
        quantity: $ordQuantity
        orderdate: $ordDate
      }
    }){
      orderline {
        orderlineid
        orderid
        prodId
        quantity
        orderdate
      }
  } 
}



# Part4 New CustHist
mutation newCustHist($clientMutID: String = "", $custID: Int = 0, $ordID: Int!, $ordProduct:Int!){
  

  createCustHist(input:{
      clientMutationId: $clientMutID

      custHist:{
        customerid: $custID
        orderid: $ordID
        prodId: $ordProduct
      }
    }){
      custHist{
        customerid
        orderid
        prodId
      }
    }
  
}


query getOrdID($oid: Int!){

  orderByOrderid(orderid: $oid) {
    orderid
    orderdate
    customerid
    netamount
    tax
    totalamount
  }
}



# Part5, do some thing using Express, or w/e

