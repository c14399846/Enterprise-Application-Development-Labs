//import createServer from "http";
//import postgraphile from "postgraphile";


const server = require("http");
const graph = require("postgraphile");

// https://stackoverflow.com/questions/34802333/nodejs-postgres-error-getaddrinfo-enotfound
//var conString = "pg://someuser:pass@db-endpoint:8080/postgres";


// "postgres//postgres:postgres@localhost:5432/dellstore2"
//var conString = "postgres:postgres//localhost:5432/dellstore2";
var conString = "postgres://postgres:postgres@localhost:5432/";

server.createServer(graph.postgraphile(conString));