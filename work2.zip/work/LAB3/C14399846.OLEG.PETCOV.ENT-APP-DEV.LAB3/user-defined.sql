// help from here
//	https://www.youtube.com/watch?v=b3pwlCDy6vY

create function postgraphile.customers_full_name(customer postgraphile.customers) returns text as $$
	select customer.firstname || ' ' || customer.lastname
$$ language sql stable;