

import createServer from "http";
import postgraphile from "postgraphile";

createServer(postgraphile());