
// C14399846
// OLEG PETCOV
// DT228/4 COMPUTER SCIENCE
// ENTERPRISE APPLICATION DEVELOPMENT
// LAB 3

var express = require('express');
var express_graphql = require('express-graphql');
var { buildSchema } = require('graphql');
var app = express();

var router = express.Router();
var pg = require('pg');

var connectionString = 'postgres://postgres:postgres@localhost:5432/dellstore2';


// help from here
// http://jamesmensch.com/tutorials/graphql-and-postgresql-node-quickstart/
var pgPromise = require('pg-promise');
var pgp = pgPromise({}); 
var psql = pgp(connectionString); // get connection to your db instance




// help from here too 
// http://graphql.org/graphql-js/running-an-express-graphql-server/
// https://medium.com/codingthesmartway-com-blog/creating-a-graphql-server-with-node-js-and-express-f6dddc5320e1
// https://medium.com/graphql-mastery/setting-up-basic-graphql-server-in-node-js-with-express-c25eeaa819c2

// GraphQL schema
var schema = buildSchema(`
    type Query {
		test: String
        customer(custID: Int!): [Customers]!
        customers: [Customers]!
    },
	
    type Customers {
        customerid: Int!
        firstname: String
        lastname: String
        address1: String
        address2: String
        city: String
        state: String
        zip: Int
        country: String
        region: String
        email: String
        phone: String
        creditcardtype: String
        creditcard: String
        creditcardexpiration: String
        username: String
        password: String
        age: Int
        income: Int
        gender: String
    }
`);




// Display customerid and name form a specific customer
var getCustomer = function(args) { 
    
	
	var custID = args.custID;
		
	var query = 'select customerid, firstname, lastname from postgraphile.customers WHERE customerid = ' + custID;
	
	console.log(query);
	
	var output = psql.any(query);
	
	return output;
	
	
	
	// Based off of documentation example code
	// doesnt work
	// junk code
	/*
	pg.connect(connectionString, (err, client, done) => {
	
		// Handle connection errors
		if(err) {
		  done();
		  console.log(err);
		  return res.status(500).json({success: false, data: err});
		}
		
		// SQL Query > Select Data
		const query = client.query('SELECT customerid, fullname FROM Customers WHERE customerid = ${cid};', {cid: custID});
		
		query.on('row', (row) => {
		  results.push(row);
		});
		
		
		// After all data is returned, close connection and return results
		query.on('end', () => {
		  done();
		  return res.json(results);
		});
	});
	*/
	
}


// Display customerid and name, from all customers 
var allCustomers = function() {
	
	var query = "select customerid, firstname, lastname from postgraphile.customers";
	
	return psql.any(query);
	
	
	
	// Based off of documentation example code
	// doesnt work
	// junk code
	/*
	pg.connect(connectionString, (err, client, done) => {
		
		// Handle connection errors
		if(err) {
		  done();
		  console.log(err);
		  return res.status(500).json({success: false, data: err});
		}
		
		// SQL Query > Select Data
		const query = client.query('SELECT firstname, lastname FROM Customers;');
		
		query.on('row', (row) => {
		  results.push(row);
		});
		
		// After all data is returned, close connection and return results
		query.on('end', () => {
		  done();
		  return res.json(results);
		});
	});
  
  */
}



var root = {
	
	test: () => {
		return 'hello';
	},
	
    customer: getCustomer,
	customers: allCustomers
};


// Create an express server and a GraphQL endpoint 
app.use('/graphql', express_graphql({
    schema: schema,
    rootValue: root,
    graphiql: true
}));

app.listen(4000, () => console.log('Express GraphQL Server Now Running On localhost:4000/graphql'));