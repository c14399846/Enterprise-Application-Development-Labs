







# Part4, mutation for new order in DB (?)


mutation testCat{
  createCategory{
    createCategoryInput{
      clientMutationId: "testMut"
      category {
        category: 22
        categoryname: "testCategory"
      }
    }
  }
}




# first test
mutation newOrder($ordDate: Date, $custID: Int = 0, $ordNet: BigFloat, $ordTax: BigFloat, $ordTotal: BigFloat){
  
  createOrderInput(){
    
  }
  
  createOrder(clientMutationId: $clientMutID, OrderInput: $orderIn){
    orderid
    orderdate
    customerid
    netamount
    tax
    totalamount
  }
  
}







# Part4, mutation for new order in DB (?)
mutation newOrder($clientMutID: String = "", $ordDate: Date!, $custID: Int = 0, $ordNet: BigFloat!, $ordTax: BigFloat!, $ordTotal: BigFloat!){
  
  createOrder(input: {
    clientMutationId:$clientMutID
    
    order:{
      orderdate: $ordDate
      customerid: $custID
      netamount: $ordNet
      tax: $ordTax
      totalamount: $ordTotal
    }   
  }) {
  
  }

  
#  createOrder(clientMutationId: $clientMutID, OrderInput: $orderIn){
#    orderid
#    orderdate
#    customerid
#    netamount
#    tax
#    totalamount
#  }
  
}





# Part4, mutation for new order in DB (?)
mutation newOrder($clientMutID: String = "", $ordDate: Date!, $custID: Int = 0, $ordNet: BigFloat!, $ordTax: BigFloat!, $ordTotal: BigFloat!){
  
  createOrder(input: {
    clientMutationId:$clientMutID
    
    order:{
      orderdate: $ordDate
      customerid: $custID
      netamount: $ordNet
      tax: $ordTax
      totalamount: $ordTotal
    }   
  }) {
    order {
    	orderid
      orderdate
      customerid
      netamount
      tax
      totalamount
  	}
  }

  
#  createOrder(clientMutationId: $clientMutID, OrderInput: $orderIn){
#    orderid
#    orderdate
#    customerid
#    netamount
#    tax
#    totalamount
#  }
  
}





# Part4, mutation for new order in DB (?)
mutation newOrder($clientMutID: String = "", $ordDate: Date!, $custID: Int = 0, $ordNet: BigFloat!, $ordTax: BigFloat!, $ordTotal: BigFloat!, $ordQuantity: Int!, $ordProduct:Int!){
  
  
  
  createOrder(input: {
    clientMutationId:$clientMutID
    
    order:{
      orderdate: $ordDate
      customerid: $custID
      netamount: $ordNet
      tax: $ordTax
      totalamount: $ordTotal
    }  
  }) {
    order {
    	orderid
      orderdate
      customerid
      netamount
      tax
      totalamount
  	}
  }
  
  createOrderline(input: {
    clientMutationId: $clientMutID
    
    orderline:{
      orderid: 1
      orderlineid: 1
    	prodId: $ordProduct
      quantity: $ordQuantity
      orderdate: $ordDate
    }
  }){
    orderline {
      orderlineid
      orderid
      prodId
      quantity
      orderdate
    }
  }
  
  createCustHist(input:{
    clientMutationId: $clientMutID
    
    custHist:{
      customerid: $custID
      orderid:1
      prodId: $ordProduct
    }
  }){
    custHist{
      customerid
      orderid
      prodId
    }
  }
  
}

