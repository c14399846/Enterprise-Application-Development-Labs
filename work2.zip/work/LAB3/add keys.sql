
//orderlines
ALTER TABLE ONLY postgraphile.orderlines
    ADD CONSTRAINT fk_prod_id FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;
	
//cust_hist	
ALTER TABLE ONLY postgraphile.cust_hist
    ADD CONSTRAINT fk_cust_hist_prod_id FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;
	
ALTER TABLE ONLY postgraphile.cust_hist
    ADD CONSTRAINT fk_cust_hist_orderid FOREIGN KEY (orderid) REFERENCES postgraphile.orders(orderid) ON DELETE CASCADE;


//categories
ALTER TABLE ONLY postgraphile.products
    ADD CONSTRAINT fk_products_category FOREIGN KEY (category) REFERENCES postgraphile.categories(category) ON DELETE CASCADE;
	
	
//inventory
ALTER TABLE ONLY postgraphile.inventory
    ADD CONSTRAINT fk_inventory_products FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;

//reorder
ALTER TABLE ONLY postgraphile.reorder
    ADD CONSTRAINT fk_reorder_products FOREIGN KEY (prod_id) REFERENCES postgraphile.products(prod_id) ON DELETE CASCADE;
	
