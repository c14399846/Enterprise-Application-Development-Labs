const todosController = require('../controllers').todos;
const todoItemsController = require('../controllers').todoItems;

const usersController = require('../controllers').users;
const purchasesController = require('../controllers').purchases;
const purchase_itemsController = require('../controllers').purchase_items;
const productsController = require('../controllers').products;


module.exports = (app) => {
  app.get('/api', (req, res) => res.status(200).send({
    message: 'Welcome to the Todos API!',
  }));

  app.post('/api/todos', todosController.create);
  app.get('/api/todos', todosController.list);
  app.get('/api/todos/:todoId', todosController.retrieve);
  app.put('/api/todos/:todoId', todosController.update);
  app.delete('/api/todos/:todoId', todosController.destroy);
  
  app.post('/api/todos/:todoId/items', todoItemsController.create);
  app.put('/api/todos/:todoId/items/:todoItemId', todoItemsController.update);
  app.delete(
    '/api/todos/:todoId/items/:todoItemId', todoItemsController.destroy
  );

  // For any other request method on todo items, we're going to return "Method Not Allowed"
  app.all('/api/todos/:todoId/items', (req, res) =>
    res.status(405).send({
      message: 'Method Not Allowed',
  }));
  
  
  app.post('/api/users', usersController.create);
  app.get('/api/users', usersController.list);
  app.get('/api/users/:userId', usersController.retrieve);
  app.put('/api/users/:userId', usersController.update);
  app.delete('/api/todos/:userId', usersController.destroy);
  
  app.post('/api/purchases', purchasesController.create);
  app.get('/api/purchases', purchasesController.list);
  app.get('/api/users/:purchaseId', purchasesController.retrieve);
  app.put('/api/users/:purchaseId', purchasesController.update);
  app.delete('/api/todos/:purchaseId', purchasesController.destroy);
  
  app.post('/api/purchase_items', purchase_itemsController.create);
  app.get('/api/purchase_items', purchase_itemsController.list);
  app.get('/api/purchase_items/:purchase_itemId', purchase_itemsController.retrieve);
  app.put('/api/purchase_items/:purchase_itemId', purchase_itemsController.update);
  app.delete('/api/todos/:purchase_itemId', purchase_itemsController.destroy);
  
  app.post('/api/products', productsController.create);
  app.get('/api/products', productsController.retrieve);
  app.get('/api/products/:productId', productsController.retrieveID);
  //app.get('/api/products[?name=string]', productsController.retrieveName);
  app.put('/api/products/:productId', productsController.update);
  app.delete('/api/products/:productId', productsController.destroy);
  
};