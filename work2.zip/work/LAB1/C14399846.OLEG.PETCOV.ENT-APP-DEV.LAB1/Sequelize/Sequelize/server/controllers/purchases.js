const Purchase = require('../models').Purchase;
const Purchase_item = require('../models').Purchase_item;

module.exports = {
  create(req, res) {
    return Purchase
      .create({
        title: req.body.title,
      })
      .then(purchase => res.status(201).send(purchase))
      .catch(error => res.status(400).send(error));
  },
  
  list(req, res) {
	return Purchase
      .findAll(/*{
        include: [{
          model: Purchase_item,
          as: 'purchase_items',
        }],
      }*/)
      .then(purchases => res.status(200).send(purchases))
      .catch(error => res.status(400).send(error));
	},
	
  retrieve(req, res) {
	  return Purchase
		.findById(req.params.purchaseId/*, {
		  include: [{
			model: Purchase_item,
			as: 'purchase_items',
		  }],
	  }*/)
		.then(purchase => {
		  if (!purchase) {
			return res.status(404).send({
			  message: 'Purchase Not Found',
		    });
		  }
		  return res.status(200).send(purchase);
		})
		.catch(error => res.status(400).send(error));
  },
	
  update(req, res) {
	  return Purchase
		.findById(req.params.purchaseId/*, {
		  include: [{
			model: Purchase_item,
			as: 'purchase_items',
		  }],
		}*/)
		.then(purchase => {
		  if (!purchase) {
			return res.status(404).send({
			  message: 'Purchase Not Found',
			});
		  }
		  return purchase
			/*.update({
			  title: req.body.title || todo.title,
			})*/
			.update(req.body, { fields: Object.keys(req.body) })
			.then(() => res.status(200).send(purchase)) 
			.catch((error) => res.status(400).send(error));
		})
		.catch((error) => res.status(400).send(error));
  },
	
  destroy(req, res) {
	  return Purchase
		.findById(req.params.purchaseId)
		.then(purchase => {
		  if (!purchase) {
			return res.status(400).send({
			  message: 'Purchase Not Found',
			});
		  }
		  return purchase
			.destroy()
			//.then(() => res.status(204).send())
			//.catch(error => res.status(400).send(error));
			.then(() => res.status(200).send({ message: 'Purchase deleted successfully.' }))
			.catch(error => res.status(400).send(error));
		})
		.catch(error => res.status(400).send(error));
  },
};