const todos = require('./todos');
const todoItems = require('./todoitems');

const users = require('./users');
const products = require('./products');
const purchases = require('./purchases');
const purchase_items = require('./purchase_items');

module.exports = {
  todos,
  todoItems,
  users,
  products,
  purchases,
  purchase_items,
};