const Purchase_item = require('../models').Purchase_item;
const Product = require('../models').Product;

module.exports = {
  create(req, res) {
    return Purchase_item
      .create({
        title: req.body.title,
      })
      .then(purchase_item => res.status(201).send(purchase_item))
      .catch(error => res.status(400).send(error));
  },
  
  list(req, res) {
	return Purchase_item
      .findAll(/*{
        include: [{
          model: Product,
          as: 'products',
        }],
      }*/)
      .then(purchase_items => res.status(200).send(purchase_items))
      .catch(error => res.status(400).send(error));
	},
	
  retrieve(req, res) {
	  return Purchase_item
		.findById(req.params.purchase_itemId/*, {
		  include: [{
			model: Product,
			as: 'products',
		  }],
	  }*/)
		.then(purchase_item => {
		  if (!purchase_item) {
			return res.status(404).send({
			  message: 'purchase_item Not Found',
		    });
		  }
		  return res.status(200).send(purchase_item);
		})
		.catch(error => res.status(400).send(error));
  },
	
  update(req, res) {
	  return Purchase_item
		.findById(req.params.purchase_itemId, {
		  /*include: [{
			model: Purchase_item,
			as: 'purchase_items',
		  }],*/
		})
		.then(purchase_item => {
		  if (!purchase_item) {
			return res.status(404).send({
			  message: 'purchase_item Not Found',
			});
		  }
		  return purchase_item
			/*.update({
			  title: req.body.title || todo.title,
			})*/
			.update(req.body, { fields: Object.keys(req.body) })
			.then(() => res.status(200).send(purchase_item)) 
			.catch((error) => res.status(400).send(error));
		})
		.catch((error) => res.status(400).send(error));
  },
	
  destroy(req, res) {
	  return Purchase_item
		.findById(req.params.purchase_itemId)
		.then(purchase_item => {
		  if (!purchase_item) {
			return res.status(400).send({
			  message: 'purchase_item Not Found',
			});
		  }
		  return purchase_item
			.destroy()
			//.then(() => res.status(204).send())
			//.catch(error => res.status(400).send(error));
			.then(() => res.status(200).send({ message: 'purchase_item deleted successfully.' }))
			.catch(error => res.status(400).send(error));
		})
		.catch(error => res.status(400).send(error));
  },
};