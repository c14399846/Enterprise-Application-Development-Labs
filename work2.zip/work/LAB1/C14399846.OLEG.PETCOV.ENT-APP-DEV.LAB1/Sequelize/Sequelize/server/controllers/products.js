const Product = require('../models').Product;

module.exports = {
	
  create(req, res) {
    return Product.create({
        title: req.body.title,
		price: req.body.price,
      })
      .then(p => res.status(201).send(p))
      .catch(error => res.status(400).send(error));
  },
  
  retrieveID(req, res) {
	  
	return Product
		.findById(req.params.productId)
		.then(product => {
		  if (!product) {
			return res.status(404).send({
			  message: 'product Not Found',
			});
		  }
		  return res.status(200).send(product);
		})
		.catch(error => res.status(400).send(error));
	},
	
  retrieve(req, res) {
	  console.log(req.query.title);
	  
	  if(req.query.name == null){
		return Product
		  .findAll(/*{
			include: [{
			  model: Purchase_item,
			  as: 'purchase_items',
			}],
		  }*/)
		  .then(products => res.status(200).send(products))
		  .catch(error => res.status(400).send(error)); 
	  }
	  
	  else {
		return Product
		.findAll({
			where: {
				title: req.query.name
			}
		})
		.then(product => {
		  if (!product) {
			return res.status(404).send({
			  message: 'product Not Found',
		    });
		  }
		  return res.status(200).send(product);
		})
		.catch(error => res.status(400).send(error));   
	  }
	  
	  
  },
  
  /*retrieveName(req, res) {
	  return Product
		.findAll({
			where:{title:req.query.name}
		  //include: [{
			//model: Purchase_item,
			//as: 'purchase_items',
		  //}],
	  })
		.then(product => {
		  if (!product) {
			return res.status(404).send({
			  message: 'product Not Found',
		    });
		  }
		  return res.status(200).send(product);
		})
		.catch(error => res.status(400).send(error));
  },*/
	
  update(req, res) {
	  return Product
		.findById(req.params.productId/*, {
		  include: [{
			model: Purchase_item,
			as: 'purchase_items',
		  }],
		}*/)
		.then(product => {
		  if (!product) {
			return res.status(404).send({
			  message: 'product Not Found',
			});
		  }
		  return product
			/*.update({
			  title: req.body.title || todo.title,
			})*/
			.update(req.body, { fields: Object.keys(req.body) })
			.then(() => res.status(200).send(product)) 
			.catch((error) => res.status(400).send(error));
		})
		.catch((error) => res.status(400).send(error));
  },
	
  destroy(req, res) {
	  return Product
		.findById(req.params.productId)
		.then(product => {
		  if (!product) {
			return res.status(400).send({
			  message: 'product Not Found',
			});
		  }
		  return product
			.destroy()
			//.then(() => res.status(204).send())
			//.catch(error => res.status(400).send(error));
			.then(() => res.status(200).send({ message: 'product deleted successfully.' }))
			.catch(error => res.status(400).send(error));
		})
		.catch(error => res.status(400).send(error));
  },
};