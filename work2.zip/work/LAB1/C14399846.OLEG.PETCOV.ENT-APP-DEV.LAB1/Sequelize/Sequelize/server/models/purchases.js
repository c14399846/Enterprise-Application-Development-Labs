
module.exports = (sequelize, DataTypes) => {
	const Purchase = sequelize.define('Purchase', {
		
		/*id:{
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true
		},*/
		name:{
			type: DataTypes.STRING,
		},
		address:{
			type: DataTypes.STRING,
		},
		state:{
			type: DataTypes.STRING,
		},
		zipcode:{
			type: DataTypes.INTEGER,
		},
		user_id:{
			type: DataTypes.INTEGER,
			/*(references: {
				model: 'User',
				key: 'id',
				as: 'user_id'
				//deferrable: Sequelize.Deferrable.INITIALLY_IMMEDIATE
			}*/
		}
	});

    Purchase.associate = (models) => {
		Purchase.belongsTo(models.User, {
			foreignKey: 'user_id',
			as: 'purchases',
			onDelete: 'CASCADE',
		});
		
		Purchase.hasMany(models.Purchase_item, {
			foreignKey: 'purchase_id',
			as: 'purchased_items',
		});
	};
	return Purchase;
};