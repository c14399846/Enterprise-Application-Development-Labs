
module.exports = (sequelize, DataTypes) => {
	const Purchase_item = sequelize.define('Purchase_item', {
	
		/*id:{
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true
		},*/
		purchase_id:{
			type: DataTypes.INTEGER,
			/*references: {
				model: 'Purchases',
				key: 'id',
				as: 'purchase_id'
				//deferrable: Sequelize.Deferrable.INITIALLY_IMMEDIATE
			}*/
		},
		product_id:{
			type: DataTypes.INTEGER,
			/*references: {
				model: 'Products',
				key: 'id',
				as: 'product_id'
				//deferrable: Sequelize.Deferrable.INITIALLY_IMMEDIATE
			}*/
		},
		price:{
			type: DataTypes.FLOAT,
		},
		quantity:{
			type: DataTypes.INTEGER,
		},
		state:{
			type: DataTypes.STRING,
		}
	});

	Purchase_item.associate = (models) => {
		/*Purchase_item.hasMany(models.Product, {
			foreignKey: 'product_id',
			as: 'products',
		});*/
		
		Purchase_item.belongsTo(models.Purchase, {
			foreignKey: 'purchase_id',
			onDelete: 'CASCADE',
		});
		
	};
	return Purchase_item;
};