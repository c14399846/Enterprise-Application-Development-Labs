
module.exports = (sequelize, DataTypes) => {
	const User = sequelize.define('User', {
		
		/*id:{
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true
		},*/
		password: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		email: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		detail: {
			type: DataTypes.HSTORE,
		}
	});

    User.associate = (models) => {
		User.hasMany(models.Purchase, {
			foreignKey: 'user_id',
			as: 'purchases',
		});
    };

	return User;
};