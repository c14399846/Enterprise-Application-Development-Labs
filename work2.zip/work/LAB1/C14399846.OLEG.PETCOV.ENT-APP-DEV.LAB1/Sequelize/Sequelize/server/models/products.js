
module.exports = (sequelize, DataTypes) => {
	const Product = sequelize.define('Product', {
		/*id:{
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true
		},*/
		title: {
			type: DataTypes.STRING,
		},
		price: {
			type: DataTypes.FLOAT,
		},
		tags: {
			type: DataTypes.ARRAY(DataTypes.STRING),
		}
	});
  
    Product.associate = (models) => {
		/*Product.belongsTo(models.Purchase_item,{
			foreignKey: 'product_id',
			//onDelete: 'CASCADE',
		});*/
	};
	
	return Product;
};