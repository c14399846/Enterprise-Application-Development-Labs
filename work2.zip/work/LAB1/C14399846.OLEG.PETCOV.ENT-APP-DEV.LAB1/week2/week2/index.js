/*const express = require("express")
const app = express()

app.get('/', (req, res) => res.send("Hello World!"))

app.listen(3000, () => console.log('Example app listening on port 3000!'))
*/



// Asynch issues?
const express = require("express");
const app = express();
const http = require('http');
const massive = require("massive");
const connectionString = "postgres://massive:@localhost/massive-test";

const SQL = require('sql-template-strings');


//https://github.com/bwestergard/node-postgres-named
const pg = require('pg'); 
const named = require('node-postgres-named');

massive({
	host: '127.0.0.1',
	port: 5432,
	database: 'pgguide',
	user: 'postgres',
	password: 'postgres'
}).then(instance => {
	app.set('db', instance);
	
	// Test query, works perfectly fine (in Chrome, not Edge)
	/*app.get('/price', (req, res) => {
		req.app.get('db').query('select id from products' ).then(items => {
			res.json(items);
		});
	});*/
	
	
	
	// USERS ID
	app.get('/users', (req, res) => {
		req.app.get('db').query('select email, details from users ORDER BY created_at DESC' ).then(items => {
			res.json(items);
		});
	});
	
	app.get('/users/:id', (req, res) => {
		req.app.get('db').query('select email, details from users where id = ' + req.params.id).then(items => {
			res.json(items);
		});
	});
	
	

	// PRODUCTS ID
	app.get('/products', (req, res) => {
		
		let title = req.query.name;

		// TRYING TO GET OTHER TYPES OF QUERY INJECTION
		// http://localhost:3000/products?name=%27Romantic%27;select%20*%20from%20users;--
		//req.app.get('db').query("select id, title from products WHERE title =" + title).then(items => {
		//	res.json(items);
		//});
		
		if (req.query.name){
			req.app.get('db').query('select id, title from products WHERE title = ${something}', {something: title}
			).then(items => {
				res.json(items);
			});
		}
		else {
			req.app.get('db').query('select * from products ORDER BY price ASC' ).then(items => {
				res.json(items);
			});
		}
		
	});
	
	
	app.get('/products/:id', (req, res) => {
		
		let prod_id = req.params.id;
		
		req.app.get('db').query('select * from products WHERE id = ' + req.params.id).then(items => {
			res.json(items);
		});
		console.log(req.params);
	});
	
	
	
		// PRODUCTS NAME
	// http://localhost:3000?name=Romantic
	/*app.get('/products/', (req, res) => {
		
		let title = req.query.name;
		//let fullTitle = "\'" + title + "\'";
		
		// TRYING TO GET OTHER TYPES OF QUERY INJECTION
		// http://localhost:3000/products?name=%27Romantic%27;select%20*%20from%20users;--
		
		//req.app.get('db').query("select id, title from products WHERE title =" + title).then(items => {
		//	res.json(items);
		//});
		
		// Parameterised
		// https://dmfay.github.io/massive-js/
		req.app.get('db').query('select id, title from products WHERE title = ${something}', {something: title}
		).then(items => {
			res.json(items);
		});
	});
	*/
	
	
	// PURCHASES ID
	// JOIN QUERY THING HERE
	app.get('/purchases', (req, res) => {
		
		//let sql = 'select * from purchases' ;
		
		//let sql = "SELECT users.email, users.details, purchases.address, purchase_items.price, purchase_items.quantity,	purchase_items.state \
		
		let sql = "SELECT users.email, purchases.name, purchases.address, purchase_items.price, purchase_items.quantity, purchase_items.state  \
		FROM users \
		INNER JOIN purchases \
		ON users.id = purchases.user_id \
		INNER JOIN purchase_items \
		ON purchases.id = purchase_items.purchase_id";
		
		req.app.get('db').query(sql).then(items => {
			res.json(items);
		});
	});
	
	app.get('/purchases/:id', (req, res) => {
		req.app.get('db').query('select * from purchases WHERE id = ' + req.params.id).then(items => {
			res.json(items);
		});
	});
	
	
	
	
	


	http.createServer(app).listen(3000);
});