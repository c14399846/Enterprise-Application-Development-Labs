/*
C14399846
OLEG PETCOV
DT228/4 COMPUTER SCIENCE

Enterprise Application Development LAB2
JWT Authentication
*/


/*
 * HELPFUL LINKS:
 *
 * JWT OFFICIAL GITHUB:
 *		https://github.com/auth0/node-jsonwebtoken
 *
 * NICE JWT CODE EXAMPLE:
 *		https://deepstreamhub.com/tutorials/guides/jwt-auth/
 *
 * HOW TO USE PGCRYPTO IN PSQL:	
 * 		https://www.meetspaceapp.com/2016/04/12/passwords-postgresql-pgcrypto.html
 *
 * EXAMPLE CODE HAD MISSING BIT FOR 'bodyParser' + 'urlencoded forms' :	
 *		https://stackoverflow.com/questions/9177049/express-js-req-body-undefined
 *
 * RSA-KEY GENERATOR:
 *		http://travistidwell.com/jsencrypt/demo/
 * 
 * BEARER AUTHORIZATION STUFF:
 *		https://github.com/auth0/express-jwt
 * 
 * 
*/


/*

// --POSTGRES TABLE CREATION STUFF--

CREATE TABLE products(
  id int PRIMARY KEY NOT NULL,
  name text NOT NULL,
  price int NOT NULL,
  descrip text
);

CREATE TABLE users (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  email text NOT NULL,
  password text NOT NULL
);

// NB: 'bf' is the type of algorithm used, not the salt phrase

INSERT INTO users (name, email, password) VALUES ('John Doe','jd@email.com', crypt('crappypassword', gen_salt('bf', 8)));
INSERT INTO products (id, name, price, descrip) VALUES (1, 'Shoes', 300, 'THESE SHOES RULE') ;
INSERT INTO products (id, name, price, descrip) VALUES (2, 'Shoes', 30, 'THESE SHOES SUCK') ;

*/





const express = require("express");
const http = require("http");
const massive = require("massive");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();

// https://stackoverflow.com/questions/9177049/express-js-req-body-undefined
// Fixes empty 'body'
app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

const conntectionInfo = {
    host: "127.0.0.1",
    port: 5432,
    database: "lab2",
	user: 'postgres',
	password: 'postgres'
};

/*
 * --RUN THIS IN 'git bash', OR SOME OTHER 'Unix-y' COMMAND LINE TOOL--
 * You need to generate your own keys here.
 * 
 * ssh-keygen -t rsa -b 4096 -f keys/jwtRS256.key
 * openssl rsa -in keys/jwtRS256.key -pubout -outform PEM -out keys/jwtRS256.key.pub
 * 
 */


const privateKey = fs.readFileSync("keys/jwtRS256.key");
const publicKey = fs.readFileSync("keys/jwtRS256.key.pub");

// RSA key generator 
// http://travistidwell.com/jsencrypt/demo/
//const privateKey = fs.readFileSync("keys/priv.key");
//const publicKey = fs.readFileSync("keys/public.key.pub");


// 'Options' vars
const iss = "Lab2 Issuer";
const sub = "Lab2 subject";
const aud = "Lab2 audience";
const exp = 300;

const tokenAge = '24h'; //24 hours
//var tokenAge = 30; //30 seconds


massive(conntectionInfo).then(instance => {
    app.set("db", instance);
	
    // This endpoint must be publicly-accessible
    app.post("/login", (req, res) => {
		
		/*
         * The steps for implementing a login endpoint are as follows:
         * 
         *  1. Query the database to check that the passwd sent in the request
         *     body (when hashed) matches the stored hash associated with username.
         *     This can be done in the database (more secure) or in Express
         *  2. If not matched reply with a 401. Otherwise, if matched, then build
         *     a claims object with the user id and an expiry timestamp.
         *  3. Pass with to jwt.sign() and the private key
         *  4. Respond to the requesting client with the resulting JWT-TOKEN with a
         *     status of 200
         */
        // YOUR CODE GOES HERE
		
		
		// How to use pgcrypt
		// https://www.meetspaceapp.com/2016/04/12/passwords-postgresql-pgcrypto.html
		
		

		if (!req.body) { return res.sendStatus(400); }

		//console.log(req.body);
		
		if (!req.body.username || !req.body.password) {
			return res.status(400).send('Missing username or password');
		}

		
		var user = req.body.username;
		var pass = req.body.password;
		
		let SQL =  'SELECT id, email FROM users WHERE email = lower(${userLogin}) AND password = crypt(${passLogin}, password)';
		
		req.app.get("db")
		.query(SQL, {userLogin: user, passLogin : pass})
		.then(items => {
			
			// If you find a user that matches the given parameters, make a token
			if (items.length > 0) {				
				
				// Options for token
				/*var options = {
					issuer: iss,
					subject: sub,
					audience: aud,
					expiresIn: exp,
					algorithm: "RS256"
				};*/

				
				var token = jwt.sign({ user: items, expire : tokenAge}, privateKey, {expiresIn: tokenAge, algorithm: "RS256"});
				
				res.status(200).json({token: token});
				
			} else {
				res.status(400).send('Incorrect login entry');
			}
		})
		.catch(error => res.status(400).send(error));
		
    });
	
	
	
    // This endpoint is publicly-accessible (by choice)
    app.get("/products/:id", (req, res) => {
        req.app
            .get("db")
            .query("select * from products where id = $1", [req.params.id])
            .then(items => {
                res.status(200).json(items);
            })
            .catch(error => res.status(400).send(error));
    });

	
	
	// Authentication is performed on all '/api/' portals
	app.all('/api/*', authenticate, function (req, res, next) {
		next();
	});
	

	// Need authentication to view all products
    app.get("/api/products", (req, res) => {
		
		req.app.get('db'
		).query("SELECT * FROM products")
		.then(products => {
			res.status(200).json(products);
		})
		.catch(error => res.status(400).send(error));
		
		//res.status(200).send("Successfully authenticated");
    });



	// Can insert new products if token is created and active
    app.post("/api/products", (req, res) => {
		
		// If 'body' data was included in the POST, attempt to insert that data 
		if (res.locals.body) {
			
			let prodData = res.locals.body;
		
			let id = prodData.id;
			let name = prodData.name;
			let price = prodData.price;
			let descrip = prodData.descrip;
			if (!descrip) {descrip = "";}
			
			let SQL = "INSERT INTO products (id, name, price, descrip) values (${prodID},${prodName},${prodPrice},${prodDesc})";
			
			req.app.get("db")
			.query(SQL, {prodID: id, prodName : name, prodPrice : price, prodDesc : descrip})
			.catch(error => res.status(400).send(error));
			
			res.status(200).json("Inserted data.");
			
		} else {
			res.status(400).send("No data given.");
		}

    });
	
	
	// Sends a simple 200 status with text
	app.get("/api/testRoute", (req, res) => {
        // Not actually implemented
        res.status(200).send("Successfully authenticated the testRoute");
    });
	

    http.createServer(app).listen(3000);
});


// Authentication middleware for protected endpoints
function authenticate(req, res, next) {
	
    /*
     * The steps for completing this function are as follows:
     * 
     *  1. Extract the authorization header from req.headers
     *  2. The needs to be of the form:
     *         BEARER JWT-TOKEN
     *  3. Parse the authorization header to extract the value of JWT-TOKEN
     *  4. Call the jwt.verify() function passing this and the public key
     *  5. If they match then call next(), otherwise respond with a 401
     */
    // YOUR CODE GOES HERE

	var headers = req.headers;
	var auth = headers.authorization;
	
	
	// Options for token
	/*var verifyOptions = {
		
		issuer: iss,
		subject: sub,
		audience: aud,
		maxAge: exp,
		algorithm: "RS256"
	}*/
	
	
	// Token extracted from headers
	var token;
	
	// Bearer authorization
	// https://github.com/auth0/express-jwt
	if (auth && auth.split(' ')[0] === 'Bearer') {
		token = auth.split(' ')[1];
    } else if (req.query && req.query.token) {
		token = req.query.token;
    } else if (auth) {
		token = auth;
	}
	
	
	jwt.verify(token, publicKey, { expiresIn: tokenAge, algorithms: ['RS256'] }, function (err, payload) {
		
		if (err){
			console.log('Token failure.');
			res.status(400).send("Authentication error.");
		} else {
			
			// Decoded token data
			//var decoded = jwt.decode(token);
			//console.log(decoded);

			res.locals.body = req.body;
			return next();
		}
	});

}
